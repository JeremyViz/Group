<footer> 
<div class="bannierefoot"></div>
<div class="contactfoot">
	<h2>CONTACT</h2>
	<div class="info">
			<a id="adress" href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwj4gIr1rpPgAhVBQhoKHfZRBfIQFjAAegQIDBAB&url=https%3A%2F%2Fmaps.google.com%2F&usg=AOvVaw3z2z03MnvIwD2K6kwtdD9z"> <img src="blblb">adresse</a>
			<a id="mail" href="https://www.google.com/gmail/">
				<img src="blbl">mail
			</a>
			<a id="telephone" href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwj0zsW3tZPgAhWLxYUKHa3gAf4QFjAAegQIBBAC&url=http%3A%2F%2Fwww.118218.fr%2F&usg=AOvVaw3w09z1lsZ4ZYu_z-erFh1I">
				<img src="blbl">telephone
			</a>
			<a id="mention" href="https://fr.lipsum.com/">Mentions Légales</a>
			<a id="join" href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=16&cad=rja&uact=8&ved=2ahUKEwjbr4CStpPgAhUHzYUKHe_5DOgQFjAPegQICBAB&url=http%3A%2F%2Fwww.temoinsdejehovah.org%2F&usg=AOvVaw3bIOaa_vkK7UOZLYEj4Lpn">Rejoignez-nous</a>

			
	</div>
 
</div>
</footer>