		<header>
			<div class="wrapper"></div>
			<h1>DRH-INSIDE<span class="vert">.</span></h1>
							<div class="container-fluid">
							<div class="row">
								<div class="col-md-1">
						<nav>
							<ul>
					<li><a href="main image">Acceuil</a></li>
					<li><a href="main image">Notre Action</a></li>
					<li><a href="main image">Qui sommes nous?</a></li>
					<li><a href="main image">Contact</a></li>
				</ul>
			</nav></div>
							</div>
			
			
    	</header>