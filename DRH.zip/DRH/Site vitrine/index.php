<DOCTYPE html>
	<!DOCTYPE html>
	<html>
	<head>
		<title>DRH Inside</title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		 
	</head>
	<body>
	<?php  
		include("header.php")
		?>
    	<section id="main image">
    		<div class="wrapper"></div>
    		
    	</section>

	<?php
		include("footer.php")
		?>

	
	</body>
	</html>